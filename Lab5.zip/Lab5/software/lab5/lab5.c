/*
 * lab5.c
 *
 *  Created on: Mar 31, 2025
 *      Author: rjd5748
 */
#include "io.h"
#include <stdio.h>
#include "system.h"
#include "alt_types.h"
#include "sys/alt_irq.h"
//#include "altera_avalon_timer_regs.h"
//#include "altera_avalon_timer.h"
// Create standard embedded type definitions
typedef signed char   sint8;
typedef unsigned char uint8;
typedef signed short  sint16;
typedef unsigned short uint16;
typedef signed long   sint32;
typedef unsigned long uint32;


// Define pointers to the base addresses of peripherals
//uint32* led_ptr = (uint32*)LEDS_BASE;
uint32* hex0_ptr = (uint32*)HEX0_BASE;
uint32* hex1_ptr = (uint32*)HEX1_BASE;
uint32* hex2_ptr = (uint32*)HEX2_BASE;
uint32* hex3_ptr = (uint32*)HEX3_BASE;
uint32* hex4_ptr = (uint32*)HEX4_BASE;
uint32* pushbutton_ptr = (uint32*)PUSHBUTTONS_BASE;
uint32* switch_ptr = (uint32*)SWITCHES_BASE;
uint32* servo_ptr = (uint32*)SERVO_CONTROLLER_0_BASE;


uint8 hex0_val = 0;
uint8 hex1_val = 0;
uint8 hex2_val = 0;
uint8 hex3_val = 0;
uint8 hex4_val = 0;
//uint8 led_state = 0xFF;

unsigned int min;
unsigned int max;

unsigned char servoMin = 45;
unsigned char servoMax = 135;

unsigned int swVal;

int hexVal[] = {0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x78, 0x00, 0x18};

void key1_isr(void* context) {
    uint32 key_edge = *(pushbutton_ptr + 3);
    *(pushbutton_ptr + 3) = key_edge;

    min = *pushbutton_ptr & 0x8;
    max = *pushbutton_ptr & 0x4;

    swVal = *switch_ptr & 0xFF;

    if(min == 0) {//looks if pushbutton furthest left is pushed

    	if((swVal >= 45) && (swVal < 100)){
    		servoMin = swVal;

    		*hex4_ptr = hexVal[swVal / 10];//display min left character
    		*hex3_ptr = hexVal[swVal % 10];//display min right character
    	}

    }

    if(max == 0) {//looks if pushbutton furthest left is pushed

        	if((swVal >= 45) && (swVal <= 135)){
        		servoMax = swVal;

        		*hex2_ptr = hexVal[swVal / 100];//display max left character
        		*hex1_ptr = hexVal[(swVal % 100)/10];//display max middle character
        		*hex0_ptr = hexVal[swVal % 10];//display max right character
        	}
        }

}
/*
void timer_isr(void* context) {
    //led_state = ~led_state;
   // *led_ptr = led_state;
    unsigned char current_val;
    *timer_ptr = 0; // Reset timer
    current_val = *led_ptr; // read the leds
    *led_ptr = current_val + 1;  // change the display
    return;
}*/
void servo_isr(void* context){
	uint32 pulse =(uint32)((555.5556 * servoMin) + 25000);
	if(servoMin == servoMax)
	{
		*servo_ptr = pulse;
		*(servo_ptr + 1) = pulse;
	}
	else
	{
		*servo_ptr = (uint32)((555.5556 * servoMin) + 25000);
		*(servo_ptr + 1) = (uint32)((555.5556 * servoMax) + 25000);
	}
}



int main(void) {
    // Initialize hex display to 0
    //*hex_ptr = 0x40; // Hex value for 0


    // Register pushbutton interrupt
     // Enable interrupt for key1
    alt_ic_isr_register(PUSHBUTTONS_IRQ_INTERRUPT_CONTROLLER_ID, PUSHBUTTONS_IRQ, key1_isr, 0, 0);
    *(pushbutton_ptr + 2) = 0xC;

    *hex0_ptr = hexVal[5];
    *hex1_ptr = hexVal[3];
    *hex2_ptr = hexVal[1];

    *hex3_ptr = hexVal[5];
    *hex4_ptr = hexVal[4];

    // Configure timer for periodic interrupts
    //*(timer_ptr + 2) = (uint16)(0x02FA); // Set timer period
    //*(timer_ptr + 3) = (uint16)(0xF080); // Set timer control register

    // Register timer interrupt

    alt_ic_isr_register(SERVO_CONTROLLER_0_IRQ_INTERRUPT_CONTROLLER_ID, SERVO_CONTROLLER_0_IRQ, servo_isr, 0, 0);

    // Start timer
    //*(timer_ptr + 1) = 0x05; // Enable interrupt, non-continuous mode, start timer
    //*led_ptr = 0; /* initial value to leds */

        // Update hex display based on hex_val






       /* switch (hex_val) {
            case 0: *hex_ptr = 0x40; break;
            case 1: *hex_ptr = 0x79; break;
            case 2: *hex_ptr = 0x24; break;
            case 3: *hex_ptr = 0x30; break;
            case 4: *hex_ptr = 0x19; break;
            case 5: *hex_ptr = 0x12; break;
            case 6: *hex_ptr = 0x02; break;
            case 7: *hex_ptr = 0x78; break;
            case 8: *hex_ptr = 0x00; break;
            case 9: *hex_ptr = 0x18; break;
        }*/
    	while (1)
    return 0;
}



